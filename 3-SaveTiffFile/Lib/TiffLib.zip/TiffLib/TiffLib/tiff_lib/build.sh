#!/bin/bash

# run NDK build
NDK_PATH=/opt/android-ndk-r10e
$NDK_PATH/ndk-build -B \
        APP_ABI="armeabi arm64-v8a" \
        APP_PLATFORM=android-21 \
        APP_BUILD_SCRIPT=Android.mk \
        NDK_PROJECT_PATH=./ \
        NDK_OUT=./out/obj  \
        NDK_LIBS_OUT=./out/libs

#cp out/obj/local/arm64-v8a/libtiff.a ../../../apk/fpSensorImageCapture/jni/prebuild-libs/arm64-v8a/libtiff.a
#cp out/obj/local/armeabi-v7a/libtiff.a ../../../apk/fpSensorImageCapture/jni/prebuild-libs/armeabi-v7a/libtiff.a
#cp out/obj/local/armeabi/libtiff.a ../../../apk/fpSensorImageCapture/jni/prebuild-libs/armeabi/libtiff.a
