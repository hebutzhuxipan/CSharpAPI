#include "tiffio.h"

int TIFFSaveFile(unsigned int width,  unsigned int height, unsigned int bitwidth, char* buf, char *strname)
{
    if( !strname || !buf ) return -1;
    if( bitwidth % 8 ) return -1;
    
	int             bits_per_pixel =  bitwidth;
    int             linesize =  width * bits_per_pixel / 8;
	TIFF *          tif;

	if ((tif = TIFFOpen(strname, "wb")) == NULL) {
		//fprintf(stderr, "can't open %s as a TIFF file\n", argv[3]);
		//free(gray);
		return -1;
	}

	TIFFSetField(tif, TIFFTAG_IMAGEWIDTH, width);
	TIFFSetField(tif, TIFFTAG_IMAGELENGTH, height);
	TIFFSetField(tif, TIFFTAG_BITSPERSAMPLE, bits_per_pixel);
	TIFFSetField(tif, TIFFTAG_COMPRESSION, COMPRESSION_NONE);
	TIFFSetField(tif, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK);
	TIFFSetField(tif, TIFFTAG_SAMPLESPERPIXEL, 1);
	TIFFSetField(tif, TIFFTAG_ROWSPERSTRIP, height);
	//TIFFSetField(tif, TIFFTAG_MAXSAMPLEVALUE, (1 << bits_per_pixel) - 1);
	TIFFSetField(tif, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);
//	TIFFSetField(tif, TIFFTAG_REFERENCEBLACKWHITE, refblackwhite);
	//TIFFSetField(tif, TIFFTAG_TRANSFERFUNCTION, gray);
	TIFFSetField(tif, TIFFTAG_RESOLUTIONUNIT, RESUNIT_NONE);

 //    int i;
	// for (i = 0; i < height; i++) {
	// 	TIFFWriteScanline(tif, buf + i * linesize, i, 0);
	// }
 	TIFFWriteEncodedStrip(tif, 0, buf, linesize * height);

	//free(scan_line);
	TIFFClose(tif);
	return 0;
}
