// TiffTest.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include<iostream>
#include "tiffAPI.h"
using namespace std;
#pragma comment(lib,"TiffLib.lib")
int main()
{
	char bmp_buf[64 * 64*2] = {'0'};
	char * img_file_name = "xpzhu2.tiff";
	TIFFSaveFile(64, 64, 16, bmp_buf, (char *)img_file_name);
	printf("test OK\n");
	getchar();
	return 0;
}
