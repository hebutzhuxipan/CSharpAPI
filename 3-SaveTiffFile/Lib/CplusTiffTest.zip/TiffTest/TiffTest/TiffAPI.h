#ifndef	TIFFAPI_H
#define TIFFAPI_H
extern "C" int TIFFSaveFile(unsigned int width, unsigned int height, unsigned int bitwidth,
	char *buf, char *strname);
#endif