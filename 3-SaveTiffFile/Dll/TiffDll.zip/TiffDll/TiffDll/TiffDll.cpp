// TiffDll.cpp : ���� DLL Ӧ�ó���ĵ���������
//

#include "stdafx.h"
#include <stdio.h>

extern "C" int TIFFSaveFile(unsigned int width, unsigned int height, unsigned int bitwidth,
	char *buf, char *strname);

extern "C"  _declspec(dllexport)int TIFFSaveFileCSharp(unsigned int width, unsigned int height, unsigned int bitwidth, char* buf, char* strname)
{
	return TIFFSaveFile(width, height, bitwidth, buf, strname);
}