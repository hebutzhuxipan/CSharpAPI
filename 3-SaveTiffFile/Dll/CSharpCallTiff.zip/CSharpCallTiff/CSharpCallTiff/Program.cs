﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices; 

namespace CSharpCallTiff
{
    unsafe class CPP_TIFF_DLL
    {
        [DllImport("TiffDll.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int TIFFSaveFileCSharp(int width, int height, int bitwidth, byte* buf, byte[] path);
    }

    class Program
    {
        unsafe static void Main(string[] args)
        {
            byte[] bufBmp = new byte[32 * 32 * 2];
            Random dd = new Random();
            //for (int i = 0; i < bufBmp.Count(); i++)
            //    bufBmp[i] = (byte)dd.Next(0, 255);

            ushort[] buf16Tiff = new ushort[32 * 32];
            for (int j = 0; j < buf16Tiff.Count(); j++)
                buf16Tiff[j] = (ushort)dd.Next(50000, 60000);

            Buffer.BlockCopy(buf16Tiff, 0, bufBmp, 0, bufBmp.Count());

            string file_name ="6pzhu.tiff";
            byte[] str = Encoding.ASCII.GetBytes(file_name);

            //ushort[] s = { 0, 1, 2, 3 };
            //byte[] b = new byte[8];
            //Buffer.BlockCopy(s, 0, b, 0, 8);

            CPP_TIFF_DLL.TIFFSaveFileCSharp(32, 32, 16, (byte*)Marshal.UnsafeAddrOfPinnedArrayElement(bufBmp, 0), str);

            Console.WriteLine("test OK");
            Console.ReadKey();
        }
    }
}
